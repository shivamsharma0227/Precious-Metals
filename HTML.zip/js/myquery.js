var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("nav-scroll-up-down").style.top = "0";
  } else {
    document.getElementById("nav-scroll-up-down").style.top = "-174px";
  }
  prevScrollpos = currentScrollPos;
}
// <!-- jQuery (header dropdown) -->
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
// <!----------------------------------------------accordion----------------------------------->
var acc = document.getElementsByClassName("accordion");
var i;
var x = 15;
for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + x + "px";
    } 
  });
}
//<!----------------------------------------------accordion end----------------------------------->
$(document).ready(function() {
	$('.top-rated-slider').slick({ 	 
  		slidesToShow: 3,
  		slidesToScroll: 1,
  		dots:false,
  		arrows:true,
  		responsive: [
		    {
		      breakpoint: 800,
		      settings: {		        
		        slidesToShow: 2
		      }
		    },
		    {
		      breakpoint: 480,
		      settings: {		        
		        slidesToShow: 1
		      }
		    }
 		 ]	
	});
	$('.review-slider').slick({
		dots:true,
  		arrows:false,
  		autoplay:true,
	});	
});
//<!----------------------------------------------accordion end----------------------------------->
var acc = document.getElementsByClassName("accordion-one");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
//<!----------------------------------------------instruction popup----------------------------------->
$(document).ready(function ()
{
	//Fade in delay for the background overlay (control timing here)
	$("#bkgOverlay").delay(800).fadeIn(400);
  //Fade in delay for the popup (control timing here)
	$("#delayedPopup").delay(1000).fadeIn(400);
	//Hide dialouge and background when the user clicks the close button
	$("#btnClose").click(function (e)
	{
		HideDialog();
		e.preventDefault();
	});
});
//Controls how the modal popup is closed with the close button
function HideDialog()
{
	$("#bkgOverlay").fadeOut(400);
	$("#delayedPopup").fadeOut(300);
	$('body').removeClass('overflow');
}
/*<!---------------------------------------------expand-collapse------------------------------------>*/
$('.expand-button').on('click', function(){
  $('.special-text').toggleClass('-expanded');
  $('.expand-button').toggleClass('rotate');
  if ($('.special-text').hasClass('-expanded')) {
    $('.expand-button').html('Collapse');
  } else {
    $('.expand-button').html('Expand');    
  }
});
//for 2nd expand//
$('.expand-button-2').on('click', function(){
  $('.special-text-2').toggleClass('-expanded');
  $('.expand-button-2').toggleClass('rotate-2');
  if ($('.special-text-2').hasClass('-expanded')) {
    $('.expand-button-2').html('Collapse');
  } else {
    $('.expand-button-2').html('Expand');    
  }
});
$('#np-more').click(function(){
	$('.custom-search-more').toggle('-expanded');
});

/*<!---------------------------------------------More dropdown btn------------------------------------>*/

$("#register").click(function(){
	$("#popup-registration").parent().show();
	$('body').addClass('reg-overflow');
});
$(".cross-close").click(function(){
	$("#popup-registration").parent().hide('slow');
	$('body').removeClass('reg-overflow');
});

$("#login").click(function(){
	$("#popup-login").parent().show();
	$('body').addClass('reg-overflow');
});
$(".cross-close-login").click(function(){
	$("#popup-login").parent().hide('slow');
	$('body').removeClass('reg-overflow');
});

$(".save-searchs").click(function(){
	$("#popup-save-search").parent().show();
	$('body').addClass('save-overflow');
});
$(".cross-save-search").click(function(){
	$("#popup-save-search").parent().hide('slow');
	$('body').removeClass('save-overflow');
});

$("#premium-p").click(function(){
	$("#popup-acnt-p").parent().show();
	$('body').addClass('reg-overflow-p');
});
$(".cross-close").click(function(){
	$("#popup-acnt-p").parent().hide('slow');
	$('body').removeClass('reg-overflow-p');
});

$("#wl-budget").click(function(){
	$(".budget_wl").toggle();
});

$("#premium-np").click(function(){
	$("#popup-acnt-np").parent().show();
	$('body').addClass('reg-overflow-p');
});
$(".cross-close").click(function(){
	$("#popup-acnt-np").parent().hide('slow');
	$('body').removeClass('reg-overflow-p');
});

$("#info-txt a").click(function(){
	$(".txt-poppups").show();
	$('body').addClass('txt-ovrflw-p');
});
$(".cross-close-txt").click(function(){
	$(".txt-poppups").hide('slow');
	$('body').removeClass('txt-ovrflw-p');
});

/*<!---------------------------------------------advanced price ticker------------------------------------>*/
var acc = document.getElementsByClassName("accordion-price-ticker");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}
//<!----------------------------------------------more-instruction popup----------------------------------->